import 'package:flutter/material.dart';

void main() {
  runApp(const LostAndFoundApp());
}

// Main application
class LostAndFoundApp extends StatelessWidget {
  const LostAndFoundApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Campus Lost & Found',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// Model class for one lost or found item
class LostFoundItem {
  final String name;
  final String location;
  final String status;
  final String description;
  final IconData icon;

  const LostFoundItem({
    required this.name,
    required this.location,
    required this.status,
    required this.description,
    required this.icon,
  });
}

// Sample campus items (8 items)
const List<LostFoundItem> campusItems = [
  LostFoundItem(
    name: 'Black Wallet',
    location: 'University Library',
    status: 'Lost',
    description: 'A small black wallet containing cards. It was last seen in the library.',
    icon: Icons.account_balance_wallet,
  ),
  LostFoundItem(
    name: 'Blue Water Bottle',
    location: 'Cafeteria',
    status: 'Found',
    description: 'A blue reusable water bottle was found on a cafeteria table.',
    icon: Icons.water_drop,
  ),
  LostFoundItem(
    name: 'Student ID Card',
    location: 'Computer Lab',
    status: 'Lost',
    description:
        'A student ID card was reported missing after a computer lab class.',
    icon: Icons.badge,
  ),
  LostFoundItem(
    name: 'Wireless Earbuds',
    location: 'Lecture Hall 2',
    status: 'Found',
    description:
        'A pair of wireless earbuds was found under a classroom chair.',
    icon: Icons.headphones,
  ),
  LostFoundItem(
    name: 'Notebook',
    location: 'Block A, Room 12',
    status: 'Lost',
    description: 'A blue study notebook with lecture notes is missing.',
    icon: Icons.menu_book,
  ),
  LostFoundItem(
    name: 'House Keys',
    location: 'Main Parking Area',
    status: 'Found',
    description: 'A set of two keys was found near the main parking area.',
    icon: Icons.key,
  ),
  LostFoundItem(
    name: 'Black Backpack',
    location: 'Sports Complex',
    status: 'Lost',
    description:
        'A black backpack was last seen near the sports complex entrance.',
    icon: Icons.backpack,
  ),
  LostFoundItem(
    name: 'Wrist Watch',
    location: 'Admin Office',
    status: 'Found',
    description:
        'A silver wrist watch was handed to the campus administration office.',
    icon: Icons.watch,
  ),
];

// Home screen: displays all items using ListView.builder
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Campus Lost & Found',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Find your missing item!',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 6),
                Text('Browse the items reported by students on campus.'),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              itemCount: campusItems.length,
              itemBuilder: (context, index) {
                final item = campusItems[index];
                final isFound = item.status == 'Found';

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Theme.of(context)
                                  .colorScheme
                                  .primaryContainer,
                              child: Icon(item.icon),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                item.name,
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 5,
                              ),
                              decoration: BoxDecoration(
                                color: isFound
                                    ? Colors.green.shade100
                                    : Colors.orange.shade100,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                item.status,
                                style: TextStyle(
                                  color: isFound
                                      ? Colors.green.shade800
                                      : Colors.orange.shade900,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            const Icon(Icons.location_on_outlined, size: 18),
                            const SizedBox(width: 5),
                            Expanded(child: Text('Location: ${item.location}')),
                          ],
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            icon: const Icon(Icons.info_outline),
                            label: const Text('View Details'),
                            onPressed: () {
                              // Navigation to the details screen
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      ItemDetailsScreen(item: item),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// Details screen: shows complete information about the selected item
class ItemDetailsScreen extends StatelessWidget {
  final LostFoundItem item;

  const ItemDetailsScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final isFound = item.status == 'Found';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Item Details'),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            CircleAvatar(
              radius: 42,
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
              child: Icon(item.icon, size: 42),
            ),
            const SizedBox(height: 20),
            Text(
              item.name,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _detailRow(
                      Icons.location_on_outlined,
                      'Location',
                      item.location,
                    ),
                    const Divider(height: 24),
                    _detailRow(Icons.info_outline, 'Status', item.status),
                    const Divider(height: 24),
                    _detailRow(
                      Icons.description_outlined,
                      'Description',
                      item.description,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isFound ? Colors.green.shade100 : Colors.orange.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                isFound
                    ? 'This item has been found. Contact the campus administration to collect it.'
                    : 'This item has been reported lost. Contact campus administration if you have information.',
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(IconData icon, String title, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(value),
            ],
          ),
        ),
      ],
    );
  }
}
